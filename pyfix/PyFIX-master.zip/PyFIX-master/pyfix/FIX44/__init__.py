from pyfix.FIX44 import msgtype, messages

__author__ = 'tom'

beginstring = 'FIX.4.4'

